import './edit_index_pattern';
