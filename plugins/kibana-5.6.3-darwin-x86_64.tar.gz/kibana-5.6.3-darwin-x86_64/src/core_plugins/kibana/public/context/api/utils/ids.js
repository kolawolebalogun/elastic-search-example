function getDocumentUid(type, id) {
  return `${type}#${id}`;
}


export {
  getDocumentUid,
};
