export function savedSearchProvider(savedSearches) {
  return savedSearches;
}
